#!/bin/bash
cd ../..
rm hw1.tar
tar -cvf hw1.tar hw1
cd -
