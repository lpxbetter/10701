function [ grad ] = LRgradient( X, y, w )
    % Filler code, replace with your own.
    f = size(X,2);
    grad = zeros(f,1);
end