function [ logl ] = LRlogLikelihood( X, y, w )
    % Filler code, replace with your own.
    logl = 0;    
end