function [ p ] = LRprob( x, w )
    % Filler code, replace with your own.
    p = [0.5; 0.5];
end