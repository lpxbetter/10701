function [ sumX ] = logSum( X )
    P = exp(X);
    sumP = sum(P); 
    sumX = log(sumP);
end

