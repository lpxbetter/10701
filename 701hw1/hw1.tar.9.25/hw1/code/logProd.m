function [ xProd ] = logProd( X )
    % Filler code, replace with your own.
    xProd = sum(X);
end

