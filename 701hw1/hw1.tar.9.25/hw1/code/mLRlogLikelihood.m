function [ logl ] = mLRlogLikelihood( X, y, W )
    % Filler code, replace with your own.
    logl = 0;
end